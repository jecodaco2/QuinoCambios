import React from 'react';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="footer">
      <div className="container">
        <p className="text-lg font-medium">Copyright © {currentYear} Casa de Cambios Quino. Todos los derechos reservados.</p>
        <div className="mt-4 flex justify-center space-x-4">
          <div className="w-12 h-1 bg-white opacity-50 rounded-full"></div>
          <div className="w-12 h-1 bg-white opacity-50 rounded-full"></div>
          <div className="w-12 h-1 bg-white opacity-50 rounded-full"></div>
        </div>
      </div>
    </footer>
  );
}
