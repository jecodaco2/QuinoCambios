'use client';

import React from 'react';

// Tasas implícitas según la nueva lógica
const implicitRates = {
  T_bs_usd: 105.50, // Tasa implícita Bs/USD
  T_bs_cop: 40.00,  // Tasa implícita Bs/COP
  T_cop_usd: 4000,  // Tasa implícita COP/USD
};

// Función para redondear números (para COP/USD)
const roundNumber = (num) => {
  return Math.round(num);
};

// Cálculos según la nueva lógica
const calculateRates = () => {
  // Bs/USD
  const buy_usd = implicitRates.T_bs_usd * 0.96;
  const sell_usd = implicitRates.T_bs_usd * 1.04;
  
  // COP/Bs (spread directo en Bs/COP)
  const buy_cop_bs = implicitRates.T_bs_cop * 1.04;
  const sell_cop_bs = implicitRates.T_bs_cop * 0.96;
  
  // COP/USD
  const raw_buy = implicitRates.T_cop_usd * 0.96;
  const raw_sell = implicitRates.T_cop_usd * 1.04;
  const buy_cop_usd = roundNumber(raw_buy);
  const sell_cop_usd = Math.min(roundNumber(raw_sell), 4200);
  
  // USDT/USD
  const buy_usdt = 1.00;
  const sell_usdt = 1.00;
  
  return {
    bs_usd: { compra: buy_usd.toFixed(2), venta: sell_usd.toFixed(2), symbol: "Bs" },
    cop_bs: { compra: buy_cop_bs.toFixed(2), venta: sell_cop_bs.toFixed(2), symbol: "COP" },
    cop_usd: { compra: buy_cop_usd.toString(), venta: sell_cop_usd.toString(), symbol: "" },
    usdt_usd: { compra: buy_usdt.toFixed(2), venta: sell_usdt.toFixed(2), symbol: "" }
  };
};

// Datos de tasas calculados
const ratesData = [
  { pair: 'Dólar (USD) / Bs', ...calculateRates().bs_usd },
  { pair: 'COP / Bs', ...calculateRates().cop_bs },
  { pair: 'COP / USD', ...calculateRates().cop_usd },
  { pair: 'USDT / USD', ...calculateRates().usdt_usd },
];

export default function RatesTable() {
  // Obtener la fecha y hora actual para mostrar la última actualización
  const now = new Date();
  const formattedDate = now.toLocaleDateString('es-ES', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
  const formattedTime = now.toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <section className="section animate-fadeIn">
      <h2 className="section-title">TASAS DE CAMBIO</h2>
      <div className="overflow-x-auto">
        <table className="rates-table">
          <thead>
            <tr>
              <th>Divisa</th>
              <th>COMPRA</th>
              <th>VENTA</th>
            </tr>
          </thead>
          <tbody>
            {ratesData.map((rate, index) => (
              <tr key={rate.pair} style={{animationDelay: `${index * 0.1}s`}}>
                <td className="font-medium">{rate.pair}</td>
                <td>
                  {rate.compra}
                  {rate.symbol && <span className="text-sm ml-1">{rate.symbol}</span>}
                </td>
                <td>
                  {rate.venta}
                  {rate.symbol && <span className="text-sm ml-1">{rate.symbol}</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-sm text-gray-600 mt-3 italic">
        *Tasas referenciales, sujetas a confirmación final.
      </p>
      <p className="text-xs text-gray-500 mt-1">
        Última actualización: {formattedDate} a las {formattedTime}
      </p>
    </section>
  );
}
