'use client';

import React from 'react';
import Image from 'next/image';

export default function Header() {
  return (
    <header className="bg-white py-6 shadow-lg">
      <div className="container flex items-center justify-between">
        <div className="logo-container">
          <div className="relative">
            <Image 
              src="/images/quino-logo-nuevo.png" 
              alt="Logo Casa de Cambios Quino" 
              width={70} 
              height={70} 
              className="logo-image object-contain animate-pulse"
            />
            <div className="absolute inset-0 bg-white opacity-0 rounded-full hover:opacity-10 transition-opacity duration-300"></div>
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-[#006837]">Quino</span>
            <span className="text-sm font-semibold text-[#006837]">CASA DE CAMBIOS</span>
          </div>
        </div>
      </div>
    </header>
  );
}
