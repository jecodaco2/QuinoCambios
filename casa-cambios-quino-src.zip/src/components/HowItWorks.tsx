'use client';

import React from 'react';

export default function HowItWorks() {
  return (
    <section className="section animate-fadeIn">
      <h2 className="section-title">Nuestro Proceso de Cambio</h2>
      <div className="process-steps">
        <div className="process-step" style={{animationDelay: '0.1s'}}>
          <div className="process-step-number">1</div>
          <h3 className="font-semibold mb-3 text-lg">Calcula</h3>
          <p>Usa nuestra calculadora para ver tu cambio al instante.</p>
        </div>
        <div className="process-step" style={{animationDelay: '0.3s'}}>
          <div className="process-step-number">2</div>
          <h3 className="font-semibold mb-3 text-lg">Contacta</h3>
          <p>Haz clic en "Iniciar Cambio" para hablar con nosotros por WhatsApp.</p>
        </div>
        <div className="process-step" style={{animationDelay: '0.5s'}}>
          <div className="process-step-number">3</div>
          <h3 className="font-semibold mb-3 text-lg">Confirma y Paga</h3>
          <p>Acuerda los detalles y realiza el pago según el método convenido.</p>
        </div>
        <div className="process-step" style={{animationDelay: '0.7s'}}>
          <div className="process-step-number">4</div>
          <h3 className="font-semibold mb-3 text-lg">Recibe</h3>
          <p>Recibe tu cambio de forma rápida y segura.</p>
        </div>
      </div>
    </section>
  );
}
