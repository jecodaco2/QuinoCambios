
'use client';

import React, { useState, useEffect } from 'react';

// Define types for rates and currencies
type Currency = 'VES' | 'COP' | 'USD' | 'USDT';
type Method = 'Transferencia' | 'Efectivo' | 'Binance Pay';

type CurrencyOption = {
  currency: Currency;
  method: Method;
  label: string;
  icon?: string;
};

// Tasas implícitas según la nueva lógica
const implicitRates = {
  T_bs_usd: 105.50, // Tasa implícita Bs/USD
  T_bs_cop: 40.00,  // Tasa implícita Bs/COP (Bs por 1000 COP)
  T_cop_usd: 4000,  // Tasa implícita COP/USD
};

// Función para redondear números (para COP/USD)
const roundNumber = (num) => {
  return Math.round(num);
};

// Cálculos según la nueva lógica (Perspectiva de la CASA)
const calculateRates = () => {
  // Bs/USD
  const casa_compra_usd = implicitRates.T_bs_usd * 0.96; // Casa paga esto en Bs para comprar 1 USD
  const casa_venta_usd = implicitRates.T_bs_usd * 1.04;  // Casa cobra esto en Bs para vender 1 USD
  
  // COP/Bs (spread directo en Bs/COP)
  const casa_compra_cop_por_bs = implicitRates.T_bs_cop * 0.96; // Casa paga esto en COP para comprar 1000 Bs
  const casa_venta_cop_por_bs = implicitRates.T_bs_cop * 1.04;  // Casa cobra esto en COP para vender 1000 Bs
  
  // COP/USD
  const raw_buy = implicitRates.T_cop_usd * 0.96;
  const raw_sell = implicitRates.T_cop_usd * 1.04;
  const casa_compra_usd_con_cop = roundNumber(raw_buy); // Casa paga esto en COP para comprar 1 USD
  const casa_venta_usd_con_cop = Math.min(roundNumber(raw_sell), 4200); // Casa cobra esto en COP para vender 1 USD
  
  // USDT/USD
  const casa_compra_usdt = 1.00;
  const casa_venta_usdt = 1.00;
  
  return {
    bs_usd: { compra: casa_compra_usd, venta: casa_venta_usd },
    cop_bs: { compra: casa_compra_cop_por_bs, venta: casa_venta_cop_por_bs }, // Bs por 1000 COP
    cop_usd: { compra: casa_compra_usd_con_cop, venta: casa_venta_usd_con_cop },
    usdt_usd: { compra: casa_compra_usdt, venta: casa_venta_usdt }
  };
};

const calculatedRates = calculateRates();

export default function Calculator() {
  const [amountToSend, setAmountToSend] = useState<string>('100');
  const [currencyToSend, setCurrencyToSend] = useState<string>('USD_Efectivo');
  const [currencyToReceive, setCurrencyToReceive] = useState<string>('VES_Transferencia');
  const [amountToReceive, setAmountToReceive] = useState<string>('');
  const [appliedRate, setAppliedRate] = useState<string>('');
  const [transactionType, setTransactionType] = useState<string>(''); // 'Compra' o 'Venta' desde perspectiva del usuario
  const [isCalculating, setIsCalculating] = useState<boolean>(false);

  const currencyOptions: CurrencyOption[] = [
    { currency: 'VES', method: 'Transferencia', label: 'Bs (Transferencia)' },
    { currency: 'COP', method: 'Efectivo', label: 'COP (Efectivo)' },
    { currency: 'USD', method: 'Efectivo', label: 'USD (Efectivo)' },
    { currency: 'USDT', method: 'Binance Pay', label: 'USDT (Binance Pay)' },
  ];

  const handleSwap = () => {
    const tempCurrency = currencyToSend;
    setCurrencyToSend(currencyToReceive);
    setCurrencyToReceive(tempCurrency);
    
    setIsCalculating(true);
    setTimeout(() => {
      setIsCalculating(false);
    }, 500);
  };

  // Función para calcular la conversión basada en la lógica CORREGIDA
  const calculateConversion = () => {
    if (!amountToSend || isNaN(parseFloat(amountToSend))) {
      setAmountToReceive('');
      setAppliedRate('');
      setTransactionType('');
      return;
    }

    const amount = parseFloat(amountToSend);
    const [sendCurrency] = currencyToSend.split('_');
    const [receiveCurrency] = currencyToReceive.split('_');

    let rate = 0;
    let rateDescription = '';
    let type = '';

    // Determinar la tasa a aplicar según las divisas seleccionadas y la lógica CORREGIDA
    // La tasa siempre se aplica sobre la moneda que se ENVÍA
    if (sendCurrency === 'USD' && receiveCurrency === 'VES') {
      // Usuario ENVÍA USD (Casa COMPRA USD) -> Usuario recibe Bs a tasa de COMPRA de la casa
      rate = calculatedRates.bs_usd.compra;
      rateDescription = `1 USD = ${rate.toFixed(2)} Bs`;
      type = 'Compra USD';
    } else if (sendCurrency === 'VES' && receiveCurrency === 'USD') {
      // Usuario ENVÍA Bs (Casa VENDE USD) -> Usuario recibe USD a tasa de VENTA de la casa
      rate = 1 / calculatedRates.bs_usd.venta;
      rateDescription = `${calculatedRates.bs_usd.venta.toFixed(2)} Bs = 1 USD`;
      type = 'Venta USD';
    } else if (sendCurrency === 'COP' && receiveCurrency === 'VES') {
      // Usuario ENVÍA COP (Casa COMPRA COP) -> Usuario recibe Bs a tasa de COMPRA de la casa (ajustada por 1000)
      rate = calculatedRates.cop_bs.compra / 1000; // Tasa Bs por 1 COP
      rateDescription = `1000 COP = ${calculatedRates.cop_bs.compra.toFixed(2)} Bs`;
      type = 'Compra COP';
    } else if (sendCurrency === 'VES' && receiveCurrency === 'COP') {
      // Usuario ENVÍA Bs (Casa VENDE COP) -> Usuario recibe COP a tasa de VENTA de la casa (ajustada por 1000)
      rate = 1000 / calculatedRates.cop_bs.venta; // Tasa COP por 1 Bs
      rateDescription = `${calculatedRates.cop_bs.venta.toFixed(2)} Bs = 1000 COP`;
      type = 'Venta COP';
    } else if (sendCurrency === 'USD' && receiveCurrency === 'COP') {
      // Usuario ENVÍA USD (Casa COMPRA USD) -> Usuario recibe COP a tasa de COMPRA de la casa
      rate = calculatedRates.cop_usd.compra;
      rateDescription = `1 USD = ${calculatedRates.cop_usd.compra} COP`;
      type = 'Compra USD';
    } else if (sendCurrency === 'COP' && receiveCurrency === 'USD') {
      // Usuario ENVÍA COP (Casa VENDE USD) -> Usuario recibe USD a tasa de VENTA de la casa
      rate = 1 / calculatedRates.cop_usd.venta;
      rateDescription = `${calculatedRates.cop_usd.venta} COP = 1 USD`;
      type = 'Venta USD';
    } else if (sendCurrency === 'USDT' && receiveCurrency === 'USD') {
      // Usuario ENVÍA USDT (Casa COMPRA USDT) -> Usuario recibe USD a tasa de COMPRA de la casa
      rate = calculatedRates.usdt_usd.compra;
      rateDescription = `1 USDT = ${calculatedRates.usdt_usd.compra.toFixed(2)} USD`;
      type = 'Compra USDT';
    } else if (sendCurrency === 'USD' && receiveCurrency === 'USDT') {
      // Usuario ENVÍA USD (Casa VENDE USDT) -> Usuario recibe USDT a tasa de VENTA de la casa
      rate = 1 / calculatedRates.usdt_usd.venta;
      rateDescription = `1 USD = ${(1 / calculatedRates.usdt_usd.venta).toFixed(2)} USDT`;
      type = 'Venta USDT';
    } else if (sendCurrency === 'USDT' && receiveCurrency === 'VES') {
      // Usuario ENVÍA USDT (Casa COMPRA USDT) -> Usuario recibe Bs (USDT->USD Compra * USD->Bs Compra)
      const usdtToUsd = calculatedRates.usdt_usd.compra;
      const usdToVes = calculatedRates.bs_usd.compra;
      rate = usdtToUsd * usdToVes;
      rateDescription = `1 USDT = ${rate.toFixed(2)} Bs`;
      type = 'Compra USDT';
    } else if (sendCurrency === 'VES' && receiveCurrency === 'USDT') {
      // Usuario ENVÍA Bs (Casa VENDE USDT) -> Usuario recibe USDT (Bs->USD Venta * USD->USDT Venta)
      const vesToUsd = 1 / calculatedRates.bs_usd.venta;
      const usdToUsdt = 1 / calculatedRates.usdt_usd.venta;
      rate = vesToUsd * usdToUsdt;
      rateDescription = `${(1 / rate).toFixed(2)} Bs = 1 USDT`;
      type = 'Venta USDT';
    } else if (sendCurrency === 'USDT' && receiveCurrency === 'COP') {
      // Usuario ENVÍA USDT (Casa COMPRA USDT) -> Usuario recibe COP (USDT->USD Compra * USD->COP Compra)
      const usdtToUsd = calculatedRates.usdt_usd.compra;
      const usdToCop = calculatedRates.cop_usd.compra;
      rate = usdtToUsd * usdToCop;
      rateDescription = `1 USDT = ${rate.toFixed(0)} COP`;
      type = 'Compra USDT';
    } else if (sendCurrency === 'COP' && receiveCurrency === 'USDT') {
      // Usuario ENVÍA COP (Casa VENDE USDT) -> Usuario recibe USDT (COP->USD Venta * USD->USDT Venta)
      const copToUsd = 1 / calculatedRates.cop_usd.venta;
      const usdToUsdt = 1 / calculatedRates.usdt_usd.venta;
      rate = copToUsd * usdToUsdt;
      rateDescription = `${(1 / rate).toFixed(0)} COP = 1 USDT`;
      type = 'Venta USDT';
    } else {
      // Mismo tipo de moneda
      rate = 1;
      rateDescription = `Conversión 1:1`;
      type = 'Misma Moneda';
    }

    const result = amount * rate;
    setAmountToReceive(result.toFixed(2));
    setAppliedRate(rateDescription);
    setTransactionType(type); // Actualizar tipo de transacción
  };

  // Recalcular cuando cambian los valores
  useEffect(() => {
    setIsCalculating(true);
    const timer = setTimeout(() => {
      calculateConversion();
      setIsCalculating(false);
    }, 300);
    
    return () => clearTimeout(timer);
  }, [amountToSend, currencyToSend, currencyToReceive]);

  return (
    <div className="calculator-container animate-fadeIn">
      <h2 className="text-2xl font-bold text-center mb-4 text-[#006837]">Calcula tu Cambio</h2>
      {/* Indicador Compra/Venta */}
      <div className="text-center mb-4 font-semibold text-lg text-gray-700">
        {transactionType.includes('Compra') ? `Estás Vendiendo ${currencyToSend.split('_')[0]}` : transactionType.includes('Venta') ? `Estás Comprando ${currencyToReceive.split('_')[0]}` : ''}
        {transactionType && <span className="text-sm text-gray-500"> (Tasa de {transactionType.split(' ')[0]} de la Casa)</span>}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6 items-center">
        {/* Send Section */}
        <div className="md:col-span-2">
          <div className="input-group">
            <label htmlFor="send-amount" className="font-medium">Tú Envías</label>
            <input
              type="number"
              id="send-amount"
              className="input-field"
              value={amountToSend}
              onChange={(e) => setAmountToSend(e.target.value)}
              placeholder="0,00"
              min="0"
              step="any"
            />
          </div>
          <div className="input-group">
            <select
              id="send-currency"
              className="select-field"
              value={currencyToSend}
              onChange={(e) => setCurrencyToSend(e.target.value)}
            >
              {currencyOptions.map(opt => (
                <option key={`${opt.currency}_${opt.method}`} value={`${opt.currency}_${opt.method}`}>{opt.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Swap Button */}
        <div className="text-center">
          <button onClick={handleSwap} className="swap-button" aria-label="Invertir divisas">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M7 10v12" />
              <path d="M15 4v12" />
              <path d="M17 15l-2 2-2-2" />
              <path d="M7 5L5 3 3 5" />
            </svg>
          </button>
        </div>

        {/* Receive Section */}
        <div className="md:col-span-2">
          <div className="input-group">
            <label htmlFor="receive-amount" className="font-medium">Tú Recibes</label>
            <input
              type="text"
              id="receive-amount"
              className={`input-field bg-gray-100 ${isCalculating ? 'animate-pulse' : ''}`}
              value={amountToReceive}
              readOnly
              placeholder="0,00"
            />
          </div>
          <div className="input-group">
            <select
              id="receive-currency"
              className="select-field"
              value={currencyToReceive}
              onChange={(e) => setCurrencyToReceive(e.target.value)}
            >
              {currencyOptions.map(opt => (
                <option key={`${opt.currency}_${opt.method}`} value={`${opt.currency}_${opt.method}`}>{opt.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Rate Display */}
      <div className="text-center text-sm text-gray-600 mt-4 font-medium">
        Tasa Aplicada: {appliedRate}
      </div>

      {/* Call to Action */}
      <div className="text-center mt-8">
        <a href="https://wa.me/584140781297" target="_blank" rel="noopener noreferrer" className="btn-primary">
          Iniciar Cambio por WhatsApp
        </a>
      </div>
    </div>
  );
}

