
import Header from "@/components/Header";
import Calculator from "@/components/Calculator";
import RatesTable from "@/components/RatesTable";
import HowItWorks from "@/components/HowItWorks";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Header />
      <div className="container">
        <Calculator />
        <RatesTable />
        <HowItWorks />
        <Contact />
      </div>
      <Footer />
    </main>
  );
}

